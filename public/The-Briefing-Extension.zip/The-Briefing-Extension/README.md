# The Briefing.

## A news aggregation web tool that provides comparative sentiment analysis of headlining stories. It focuses on helping users become more conscious consumers of media.

### Instructions for running Chrome Extension
* In Chrome, navigate to chrome://extensions/
* Turn on Developer Mode
* Drag and drop the extensions folder
* Turn on The Briefing extension
* Start analyzing news!
